package Server;

import java.net.*;
import java.io.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class EchoServer2 extends Thread {

    protected Socket clientSocket;

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;

        System.out.print("determine o port de conexao: ");
        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        int CLIENT_PORT = Integer.parseInt(stdIn.readLine());

        try {
            serverSocket = new ServerSocket(CLIENT_PORT);
            System.out.println("Connection Socket Created");
            try {
                while (true) {
                    System.out.println("Waiting for Connection");
                    new EchoServer2(serverSocket.accept());
                }
            } catch (IOException e) {
                System.err.println("Accept failed.");
                System.exit(1);
            }
        } catch (IOException e) {
            System.err.println("Could not listen on port: " + CLIENT_PORT);
            System.exit(1);
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                System.err.println("Could not close port: " + CLIENT_PORT);
                System.exit(1);
            }
        }
    }

    private EchoServer2(Socket clientSoc) {
        clientSocket = clientSoc;
        start();
    }

    @Override
    public void run() {
        System.out.println("New Communication Thread Started");

        try {
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String inputLine;

            JSONParser parser = new JSONParser();
            JSONObject inObj = new JSONObject();
            JSONObject outObj;
            int op;
            boolean logout = false;
            while (!logout && (inputLine = in.readLine()) != null) { 
                try {
                    inObj = (JSONObject) parser.parse(inputLine);
                } catch (ParseException ex) {
                    System.out.println("Erro ao converter a entrata");
                }
                op = ((Long) (inObj.get("op"))).intValue();
                System.out.println("in: " + inObj);
                switch (op) {
                    case 100 -> { //LOGIN
                        outObj = login(inObj);
                        out.println(outObj.toString());
                        System.out.println("out: " + outObj);
                        break;
                    }
                    case 200 -> {
                        logout = true;
                        break;
                    }
                    case 300 -> { //CADASTRO
                        outObj = cadastrarUsuario(inObj);
                        out.println(outObj.toString());
                        System.out.println("out: " + outObj);
                        break;
                    }
                    default -> {
                        System.out.println("OP INVALIDO: " + op);     
                        break;
                    }
                }
            }

            out.close();
            in.close();
            clientSocket.close();
        } catch (IOException e) {
            System.err.println("Problem with Communication Server");
            System.exit(1);
        }
    }

    public JSONObject login(JSONObject usuario) {

        JSONObject outObj = new JSONObject();
        JSONObject arrI;

        outObj.put("status", 102); //FALHA (PADRAO)

        JSONArray userArr;
        userArr = getUserArr();
        for (int i = 0; i < userArr.size(); i++) {
            arrI = (JSONObject) userArr.get(i);
            if (usuario.get("username").equals(arrI.get("username")) && usuario.get("password").equals(arrI.get("password"))) {
                outObj.put("status", 101); // SUCESSO
                outObj.put("wishlist", usuario.get("whishlist"));
                return outObj;
            }
        }
        return outObj;
    }

    public JSONObject cadastrarUsuario(JSONObject usuario) {

        JSONObject outObj = new JSONObject();
        JSONArray userArr;
        JSONObject arrI;

        userArr = getUserArr();

        for (int i = 0; i < userArr.size(); i++) {
            arrI = (JSONObject) userArr.get(i);
            if (usuario.get("username").equals(arrI.get("username"))) {
                outObj.put("status", 302); // USUARIO JA EXISTE
                return outObj;
            }
        }
        usuario.remove("op"); // pois a entrada manda op junto, e nao queremos adicionar isso na lista de usuarios
        userArr.add(usuario);
        try ( FileWriter fileWrite = new FileWriter("usuarios.json")) {
            fileWrite.write(userArr.toJSONString());
            outObj.put("status", 301); //SUCESSO
            return outObj;
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }

        return outObj;
    }

    public JSONArray getUserArr() {
        JSONParser parser = new JSONParser();
        JSONArray userArr = new JSONArray();

        try ( FileReader fileRead = new FileReader("usuarios.json")) {
            File file = new File("usuarios.json");
            if (file.length() == 0) {                    //CASO O ARQUIVO ESTEJA VAZIO, PRA NAO DAR ERRO COM END OF FILE
                try ( FileWriter fileWrite = new FileWriter("usuarios.json")) {
                    fileWrite.write("[]");
                } catch (IOException e) {
                    e.printStackTrace(System.out);
                }
            }
            userArr = (JSONArray) parser.parse(fileRead);

        } catch (FileNotFoundException e) {
            System.out.println("arquivo de usuarios nao encontrado");
            e.printStackTrace(System.out);
        } catch (IOException | ParseException e) {
            e.printStackTrace(System.out);
        }

        return userArr;
    }
}
