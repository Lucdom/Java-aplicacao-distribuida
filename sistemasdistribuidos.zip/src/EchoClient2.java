import java.io.*;
import java.net.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class EchoClient2 {
    public static void main(String[] args) throws IOException, Exception {

        String serverHostname = new String ("127.0.0.1");

        if (args.length > 0)
           serverHostname = args[0];
        System.out.println ("Attemping to connect to host " +
                serverHostname + " on port 10008.");

        Socket echoSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;
        JSONParser parser = new JSONParser();

        try {
            echoSocket = new Socket(serverHostname, 10008);
            out = new PrintWriter(echoSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(
                                        echoSocket.getInputStream()));
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host: " + serverHostname);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for "
                               + "the connection to: " + serverHostname);
            System.exit(1);
        }

	BufferedReader stdIn = new BufferedReader(
                                   new InputStreamReader(System.in));
	String userInput;
        
        JSONObject loginObj = new JSONObject();
        JSONObject inObj;
        JSONObject outObj = new JSONObject();
        
        loginObj.put("op", 100);
        int resposta;
        
        System.out.println("1: Login \n2: Cadastro\n0: Sair");
        while ((userInput = stdIn.readLine()) != null){
            if ((userInput.equals(""))){
                continue;
            }
            switch(Integer.parseInt(userInput)){
                case 0 -> {
                    out.close();
                    in.close();
                    stdIn.close();
                    echoSocket.close();     
                    return;
                }
                case 1 -> {
                    loginObj.put("op", 100);
                    do{
                        System.out.print("login: " );
                        userInput = stdIn.readLine();
                    }while (userInput == null); 
                    loginObj.put("username", userInput);

                    do{
                        System.out.print("senha: " );
                        userInput = stdIn.readLine();
                    }while (userInput == null); 
                    loginObj.put("senha", userInput);

                    out.println(loginObj);
                    System.out.println("enviado:" + loginObj.toString());

                    inObj = (JSONObject) parser.parse(in.readLine());
                    resposta = ((Long)inObj.get("op")).intValue();
                    if(resposta == 101){
                        System.out.println("servidor: Sucesso");
                    }               
                    else if(resposta == 102){
                        System.out.println("servidor: erro");
                    }
                }
                case 2 -> {
                    System.out.println("CADASTRO");
                    outObj.put("op", 300);
                    do{
                        System.out.print("usuario: " );
                        userInput = stdIn.readLine();
                    }while (userInput == null); 
                    outObj.put("username", userInput);

                    do{
                        System.out.print("senha: " );
                        userInput = stdIn.readLine();
                    }while (userInput == null); 
                    outObj.put("senha", userInput);
                    
                    out.println(outObj.toString());
                    System.out.println("enviado:" + outObj.toString());
                    
                    inObj = (JSONObject) parser.parse(in.readLine());
                    resposta = ((Long)inObj.get("op")).intValue();
                    if(resposta == 301){
                        System.out.println("servidor: Sucesso");
                    }               
                    else if(resposta == 302){
                        System.out.println("servidor: usuario ja existe");
                    }
                    
                    
                }
                default -> { break; }
            }
            System.out.println("1: Login \n2: cadastro\n0: Sair");
        }
        
	out.close();
	in.close();
	stdIn.close();
	echoSocket.close();
    }   
    
    public void switchOp(){  //PENSANDO EM COMO VOU SEPARAR AS COIAS
        
    }
}
