package Client;


import java.io.*;
import java.net.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class EchoClient2 {

    public static void main(String[] args) throws IOException, Exception {

        //  TELA DE CONEXAO  
        int SERVER_PORT;
        String SERVER_IP;
        EnderecoGUI telaEnd = new EnderecoGUI();

        telaEnd.setVisible(true); //inicia a tela.

        try {
            while (!telaEnd.conectado) {  //enquanto nao estiver conectado, espera.
                Thread.sleep(200);
            }
        } catch (InterruptedException e) {
            e.printStackTrace(System.out);
        }
        telaEnd.setVisible(false);  //fecha a tela.

        SERVER_IP = telaEnd.serverIP;
        SERVER_PORT = telaEnd.serverPort;

        //  CONEXAO NO SERVER
        System.out.println("Attemping to connect to host " + SERVER_IP + " on port " + SERVER_PORT);
        Socket echoSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;
        try {
            echoSocket = new Socket(SERVER_IP, SERVER_PORT);
            out = new PrintWriter(echoSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(
                    echoSocket.getInputStream()));
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host: " + SERVER_IP);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for " + "the connection to: " + SERVER_IP);
            System.exit(1);
        }
        userClass usuario;
        usuario = login(out, in);
        telaMain(out, in, usuario);
        
        out.close();
        in.close();
        echoSocket.close();
        System.exit(0);
    }

    public static userClass login(PrintWriter out, BufferedReader in) {
        //CRIANDO JSON Objects
        JSONObject inObj = new JSONObject();
        JSONObject outObj = new JSONObject();
        JSONParser parser = new JSONParser();
        int resposta;
        userClass usuario = new userClass();

        // TELA DE LOGIN/CADASTRO
        LoginCadGUI telaLogin = new LoginCadGUI();
        
        telaLogin.statusLabel.setText("");
        telaLogin.setVisible(true);
        while(true){
            while(telaLogin.clicado == false){  //ESPEAR QUE O BOTAO SEJA CLICADO
                try {
                    Thread.sleep(500); 
                } catch (InterruptedException e) {
                   e.printStackTrace();
                }
            }

            //FAZ A AÇAO DEPENDENDO DO BOTAO QUE FOI CLICADO
            switch (telaLogin.op) {
                case 1 -> {
                    outObj.put("op", 100);
                    outObj.put("username", telaLogin.username);
                    outObj.put("password", telaLogin.senha);
                    outObj.put("wishlist", 0);
                        
                    usuario.setSenha(telaLogin.senha);
                    usuario.setUsername(telaLogin.username);
                    
                    out.println(outObj);
                    System.out.println("out:" + outObj);

                    try {
                        inObj = (JSONObject) parser.parse(in.readLine());
                    } catch (ParseException | IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("in: " + inObj);
                    resposta = ((Long) inObj.get("status")).intValue();
                    if (resposta == 101) {
                        telaLogin.statusLabel.setText("login sucesso!");
                        telaLogin.setVisible(false);
                        return usuario;
                    } else if (resposta == 102) {
                        telaLogin.statusLabel.setText("login erro!");
                    }
                    break;  // OS PROBLEMAS SAO O LOOP DA LINHA 60, E FALTA DE CONTINUIDADE (LOGIN PRA LOGOUT?, PRA PROXIMA TELA?, CADASTRO SE NAO DER LOGIN?)
                }
                case 2 -> {
                    outObj.put("op", 300);
                    outObj.put("username", telaLogin.username);
                    outObj.put("password", telaLogin.senha);
                    out.println(outObj);
                    System.out.println("out:" + outObj);

                    try {
                        inObj = (JSONObject) parser.parse(in.readLine());
                    } catch (ParseException | IOException e) {
                        e.printStackTrace();
                    }

                    System.out.println("in: " + inObj);
                    resposta = ((Long) inObj.get("status")).intValue();
                    if (resposta == 301) {
                        telaLogin.statusLabel.setText("cadastro sucesso!");
                    } else if (resposta == 302) {
                        telaLogin.statusLabel.setText("usuario ja existe");
                    }
                    break;
                }
            }
            telaLogin.clicado = false;
        }
    }

    private static void telaMain(PrintWriter out, BufferedReader in, userClass usuario) {
        ClientMainGUI telaMain = new ClientMainGUI();
        telaMain.setVisible(true);
        JSONObject outObj = new JSONObject();
        while(telaMain.logout == false){  //ESPEAR QUE O BOTAO SEJA CLICADO
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
               e.printStackTrace();
            }
        }
        outObj.put("op", 200);
        out.println(outObj);
        telaMain.setVisible(false);
    }
}
