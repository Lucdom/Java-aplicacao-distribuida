
import java.net.*;
import java.io.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class EchoServer2 extends Thread {

    protected Socket clientSocket;

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(10008);
            System.out.println("Connection Socket Created");
            try {
                while (true) {
                    System.out.println("Waiting for Connection");
                    new EchoServer2(serverSocket.accept());
                }
            } catch (IOException e) {
                System.err.println("Accept failed.");
                System.exit(1);
            }
        } catch (IOException e) {
            System.err.println("Could not listen on port: 10008.");
            System.exit(1);
        } finally {
            try {
                serverSocket.close();
            } catch (IOException e) {
                System.err.println("Could not close port: 10008.");
                System.exit(1);
            }
        }
    }

    private EchoServer2(Socket clientSoc) {
        clientSocket = clientSoc;
        start();
    }

    public void run() {
        System.out.println("New Communication Thread Started");

        try {
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String inputLine;
            FileWriter fileWrite = new FileWriter("usuarios.json");
            FileReader fileRead = new FileReader("usuarios.json");

            JSONParser parser = new JSONParser();
            JSONObject inObj = new JSONObject();
            JSONObject outObj = new JSONObject();
            JSONArray userArr = new JSONArray();
            int op = -1;

            while ((inputLine = in.readLine()) != null) {
                try {
                    inObj = (JSONObject) parser.parse(inputLine);
                } catch (ParseException ex) {
                    System.out.println("Erro ao converter a entrata");
                }
                op = ((Long) (inObj.get("op"))).intValue();
                System.out.println("op: " + op);
                switch (op) {
                    case 100 -> { //LOGIN
                        outObj = login(inObj);
                        out.println(outObj.toString());
                        break;
                    }
                    case 300 -> { //CADASTRO
                        outObj = cadastrarUsuario(inObj); 
                        out.println(outObj.toString());
                        break;
                    }
                }
            }

            out.close();
            in.close();
            clientSocket.close();
        } catch (IOException e) {
            System.err.println("Problem with Communication Server");
            System.exit(1);
        }
    }

    public JSONObject login(JSONObject usuario) {
        System.out.println("login");
        JSONObject outObj = new JSONObject();
        JSONObject arrI;

        JSONArray userArr;
        JSONParser parser = new JSONParser();

        outObj.put("op", 102); //FALHA (PADRAO)

        try ( FileReader fileRead = new FileReader("usuarios.json")) {
            userArr = (JSONArray) parser.parse(fileRead);

            for (int i = 0; i < userArr.size(); i++) {
                arrI = (JSONObject) userArr.get(i);
                if (usuario.get("username").equals(arrI.get("username")) && usuario.get("senha").equals(arrI.get("senha"))) {
                    outObj.put("op", 101); // SUCESSO
                    return outObj;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace(System.out);
        } catch (IOException | ParseException e) {
            e.printStackTrace(System.out);
        }
        return outObj;
    }

    public JSONObject cadastrarUsuario(JSONObject usuario) {

        JSONObject outObj = new JSONObject();
        JSONArray userArr;
        JSONObject arrI;
        JSONParser parser = new JSONParser();

        try ( FileReader fileRead = new FileReader("usuarios.json")) {
            try ( FileWriter fileWrite = new FileWriter("usuarios.json")) {
                fileWrite.write("[]");
            } catch (IOException e) {
                e.printStackTrace(System.out);
            }

            
            userArr = (JSONArray) parser.parse(fileRead);

            for (int i = 0; i < userArr.size(); i++) {
                arrI = (JSONObject) userArr.get(i);
                if (usuario.get("username").equals(arrI.get("username"))) {
                    outObj.put("op", 302); // USUARIO JA EXISTE
                    return outObj;
                }
            }
            userArr.add(usuario);
            try ( FileWriter fileWrite = new FileWriter("usuarios.json")) {
                fileWrite.write(userArr.toJSONString());
                outObj.put("op", 301); //SUCESSO
                return outObj;
            } catch (IOException e) {
                e.printStackTrace(System.out);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace(System.out);
        } catch (IOException | ParseException e) {
            e.printStackTrace(System.out);
        }
        return outObj;
    }
}
